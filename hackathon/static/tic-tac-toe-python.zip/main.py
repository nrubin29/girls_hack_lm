'''
Created on Mar 3, 2021

@author: swopet
'''
import pygame

FPS = 60

# Creates constants for the width and height of the board.
# Edit to change the size of the board
WIDTH = 300
HEIGHT = 300
# Sets the number of rows and columns on the board 
ROWS, COLS = 3, 3

# Sets color constants
GREY = (128,128,128)
BLACK = (0, 0, 0)
BLUE = (0, 0, 100)

# This code loads an image so that you can later paint it onto your board.
# To change the image download the image then upload the file and change the image name
X = pygame.image.load("X-image.png")
O = pygame.image.load("O-image.png")

# two-dimensional array of characters. When x or o click on the a square you'll add an x or o to the corresponding location in this array.
board = [[]]

# Sets the starting player's turn to x
turn = 'x'




def draw():
# Sets the boards dimensions and gives it a title
    BOARD = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Tic-Tac-Toe')
  
    # Fills the display screen with grey
    BOARD.fill(GREY)
  
    # Draw the grid for the tic-tac-toe board. You should make each square about 100x100.
    # syntax: (display, color, (starting x, starting y, width, height))
    pygame.draw.rect(BOARD, BLUE, (100,0, 2, 300))

    # Draw the BOARD based on the board array
    # This is how you print your x and o images
    # Edit this to change the size of the image
    image = pygame.transform.scale(X, (100, 100))
    # Edit this to change the location of the image
    BOARD.blit(image, (0, 0))

  
    # Display a message if either x or o has won the game.

    # Relaods the screen with the new board
    pygame.display.update()



# Check to see if x or o have won the game.
def winner():
    return False



def main():
    draw()
    run = True
    clock = pygame.time.Clock()

    # Should detect which row and column the user clicked in, add their piece to the board,
    # switch who's turn it is and then repaint the board.
    while run:
        clock.tick(FPS)
    
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                x, y = pos
                print("x-value: " + str(x) + " y-value: " + str(y))
        
        # add a new piece to the board and redraw out the board
        
        draw()
               
    pygame.quit()


main()